package com.jagannath.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jagannath.model.Department;
import com.jagannath.service.DeptService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/dept")
@Api(value="Departnment Endpoints")
public class DeptController {
	@Autowired
	private DeptService deptService;
	
	@ApiOperation("get all Dept")
	@GetMapping
	public List<Department> getDepartment() {
		return deptService.getAllDepartment();
	}
	
	@ApiOperation(value = "Add New Department")
    @PostMapping("/add")
    public ResponseEntity<String> addDepartment(@RequestBody Department department){
		deptService.addDepartment(department);
        try {

            int num=deptService.addDepartment(department);
            if(num != 0)
                return ResponseEntity.status(HttpStatus.OK).body("Department Added Succesfully");
            else    
                return ResponseEntity.status(HttpStatus.OK).body("Department Not Added");

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	
//	@ApiOperation("create department")
//	@PostMapping("/create")
//	public void addDept(@RequestBody Department department) {
//		deptService.Adddept(department);
//
//	}
	

	@ApiOperation("update department by id")
	@PutMapping("/update/{id}")
	public void updateDeptbyid(@RequestBody Department department,@PathVariable ("id") int deptId) {
		deptService.updatedeptbyid(department, deptId);
		
	}
//	@ApiOperation("delete department by id")
//	@DeleteMapping("/delete/{id}")
//	public void deleteDept(@PathVariable ("id") int deptId) {
//		deptService.deletedept(deptId);
//		
//	}
	
	

}
