package com.jagannath.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jagannath.model.Employee;
import com.jagannath.service.EmpCountService;
import com.jagannath.service.EmpService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import com.jagannath.model.EmpCount;

@RestController
@RequestMapping("/employees")
@Api(value="Employee Endpoints")
public class Empcontroller {
	@Autowired
	EmpCountService empCountService;
	@Autowired
	private EmpService empService;
	
	@ApiOperation("get all employee")
	@GetMapping
	public List<Employee> getEmployee() {
		return empService.getAllEmployees();
	}
	@ApiOperation("create employee")
	@PostMapping("/create")
	public void addEmployee(@RequestBody Employee employee) {
		empService.AddEmployee(employee);

	}
	

	@ApiOperation("upadate employee")
	@PutMapping("/update")
	public void UpdateEmployee(@RequestBody Employee employee) {
		empService.updateEmployee(employee);

	}
	@ApiOperation("update employee by id")
	@PutMapping("/update/{id}")
	public void updatempbyid(@RequestBody Employee employee,@PathVariable ("id") int eId) {
		empService.updateempbyid(employee, eId);
		
	}
	@ApiOperation("delete employee by id")
	@DeleteMapping("/delete/{id}")
	public void deleteEmployee(@PathVariable ("id") int eId) {
		empService.deleteEmployee(eId);
		
	}
	
	@ApiOperation("get ascending list")
	@GetMapping("/asc")
	public List<Employee> employeeAsc() {
		return empService.employeeAsc();
		
	}
	@ApiOperation("get descending list")
	@GetMapping("/desc")
	public List<Employee> employeeDesc() {
		return empService.employeeDesc();
		
	}
	
//	 @PatchMapping("/{empId}/dept/{deptId}")
//	    public Employee updateEmpDepartment(@PathVariable("empId") Integer emp_id , @PathVariable("deptId") Integer dept_id) {
//	       return empService.updateEmpDepartment(emp_id,dept_id);
//	    }
	@ApiOperation("get employee count")
	@GetMapping("/empcount")
    public ResponseEntity<List<EmpCount>> getAllEmployeeByDepartmentId(){
        System.out.println(empCountService.getAllEmployeeByDepartmentId());
        List<EmpCount> list = empCountService.getAllEmployeeByDepartmentId();
        if (list.size() <= 0)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

        return ResponseEntity.status(HttpStatus.OK).body(list);
    }
	@GetMapping
    private List<Employee> getSortedEmployees(@RequestParam(name = "order",required = false) String order )
    {
       return empService.getSortedEmployees(order);

    }

}


