package com.jagannath.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jagannath.model.Employee;

public interface EmpRepo extends JpaRepository<Employee, Integer>{
	@Query(value="select * from employee order by ename;",nativeQuery = true)
    public List<Employee> sortByNameAsc();

    @Query(value="select * from employee order by ename desc;",nativeQuery = true)
    public List<Employee> sortByNameDesc();

    @Query(value="select distinct dept.deptid as dept, count(employee.id) as empCount from Employee inner join dept where employee.deptid=dept.deptid group by employee.deptid;",nativeQuery = true)
    public List<Object[]> getEmpCountByDeptId();
}
