package com.jagannath.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jagannath.model.Department;

public interface DeptRepo extends JpaRepository<Department, Integer>{

}
