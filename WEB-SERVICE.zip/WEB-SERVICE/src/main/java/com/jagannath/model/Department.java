package com.jagannath.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "dept")
public class Department {

	
	@Column(name = "deptname")
	private String dName;
	@Id
	@Column(name = "deptid")
	private int deptId;

	


	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	@Override
	public String toString() {
		return "Department [dName=" + dName + ", deptId=" + deptId + "]";
	}

}
