package com.jagannath.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jagannath.model.Department;
import com.jagannath.repository.DeptRepo;

@Service
public class DeptService {
	@Autowired
	private DeptRepo deptRepo;

	public List<Department> getAllDepartment() {
		return deptRepo.findAll();
	}
	
	

	
	
	public int addDepartment(Department department) {
		deptRepo.save(department);
        return 1;
    }
   
    


    public void updatedeptbyid(Department department,int deptid) {
    	if(deptid==department.getDeptId())
    		deptRepo.save(department);
		
	}


	public void deletedept(Integer deptid) {
		
		
		deptRepo.deleteById(deptid);
	}





	public void Adddept(Department department) {
		// TODO Auto-generated method stub
		deptRepo.save(department);
		
	}
	
}
