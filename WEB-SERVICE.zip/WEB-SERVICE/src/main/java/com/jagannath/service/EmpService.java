package com.jagannath.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.jagannath.repository.EmpRepo;
import com.jagannath.model.Department;
import com.jagannath.model.Employee;

import com.jagannath.repository.DeptRepo;


@Service
public class EmpService {


	@Autowired
	EmpRepo employeeRepository;

	@Autowired
	DeptRepo departmentRepository;

	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	
	public void AddEmployee(Employee employee) {
		employeeRepository.save(employee);

	}
    public Employee updateEmployee(Employee employee) {
        Employee emp = employeeRepository.getById(employee.geteId());
        if(emp == null) {
            throw new RestClientException("Employee with id "+employee.geteId()+" not found");
        }
        return employeeRepository.save(employee);
    }
    


    public void updateempbyid(Employee employee,int eid) {
    	if(eid==employee.geteId())
    		employeeRepository.save(employee);
		
	}


	public void deleteEmployee(Integer eId) {
		
		
		employeeRepository.deleteById(eId);
	}
	
	public List<Employee> employeeAsc() {
		return employeeRepository.sortByNameAsc();
		
	}
	public List<Employee> employeeDesc() {
		return employeeRepository.sortByNameDesc();
		
	}
	public List<Object> count()
	{
		List<Object> o=new ArrayList<Object>();
		Iterator<Object> itr=o.iterator();
		while(itr.hasNext())
		{
			o.add(employeeRepository.count());
		}
		return o;
	}
	
	public List<Employee> getSortedEmployees(String order) {List<Employee> emp = (List<Employee>) employeeRepository.findAll();
    Collections.sort(emp, new Comparator<Employee>() {

        @Override
        public int compare(Employee o1, Employee o2) {
            if ("desc".equalsIgnoreCase(order)) {
                return o2.geteName().toUpperCase().compareTo(o1.geteName().toUpperCase());
            }else {
                return o1.geteName().toUpperCase().compareTo(o2.geteName().toUpperCase());    
            }
        }

    });
    return emp;
    }
}



