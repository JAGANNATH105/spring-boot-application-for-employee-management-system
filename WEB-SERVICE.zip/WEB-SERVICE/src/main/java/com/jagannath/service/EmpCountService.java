package com.jagannath.service;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jagannath.model.EmpCount;
import com.jagannath.repository.EmpRepo;

@Service
public class EmpCountService {

	@Autowired
	private EmpRepo empRepo;

	public List<EmpCount> getAllEmployeeByDepartmentId(){
		List<Object[]> result = empRepo.getEmpCountByDeptId();
		List<EmpCount> list=new ArrayList<EmpCount>();
		if(result != null && !result.isEmpty()){
			for (Object[] object : result) {
				EmpCount emp=new EmpCount();
				emp.setDept(Integer.parseInt(object[0].toString()));
				//	               System.out.println("Dept : "+Integer.parseInt(object[0].toString()));
				emp.setEmpCount(new BigInteger(object[1].toString()).intValue());
				//	               System.out.println("Empcount : "+new BigInteger(object[1].toString()).intValue());
				list.add(emp);
			}
		}
		return list;
	}


}


