package empService;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import com.jagannath.model.Department;
import com.jagannath.model.Employee;

public class count implements Map<Employee, Department> {

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsKey(Object key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsValue(Object value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Department get(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department put(Employee key, Department value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department remove(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putAll(Map<? extends Employee, ? extends Department> m) {
		// TODO Auto-generated method stub

	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<Employee> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Department> values() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Entry<Employee, Department>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}

}
