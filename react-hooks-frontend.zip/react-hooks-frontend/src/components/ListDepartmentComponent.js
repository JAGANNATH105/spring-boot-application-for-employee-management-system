import React, {useState, useEffect} from 'react'
import { Link, useParams } from 'react-router-dom'
import DepartmentService from '../services/DepartmentService'
import ReactPaginate from 'react-paginate';

const ListDepartmentComponent = () => {

    const [department, setdepartment] = useState([])
    // const {did}=useParams();
    useEffect(() => {

        getAlldepts();
    }, [])

    const getAlldepts = () => {
        DepartmentService.getAlldepts().then((response) => {
            setdepartment(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    }
    const deletedept = (deptId) => {
        DepartmentService.deletedept(deptId).then((response) =>{
         getAlldepts();
 
        }).catch(error =>{
            console.log(error);
        })
         
     }

    return (
        <div className = "container">
            <h3 className = "text-center mt-3"> List Department </h3>
            <Link to = "/add-Department" className = "btn btn-primary mb-3" > Add Department </Link>&nbsp;&nbsp;
            <Link to = "/employees" className = "btn btn-primary mb-3" color='black'> back </Link> 

            <table className="table table-bordered table-striped">
                <thead>
                    <th>Department Id</th> 
                    <th>Department Name</th>
                    <th> Actions </th>
                </thead>
                <tbody>
                    {
                        department.map(
                            dept =>
                            <tr key = {dept.deptId}> 
                                 <td>{dept.deptId}</td> 
                                 <td>{dept.dName}</td> 
                                <td>
                                    <button className = "btn btn-danger" onClick = {() => deletedept(dept.deptId)}
                                    style = {{marginLeft:"10px"}}> Delete</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
           
            
        </div>
    )
}

export default ListDepartmentComponent