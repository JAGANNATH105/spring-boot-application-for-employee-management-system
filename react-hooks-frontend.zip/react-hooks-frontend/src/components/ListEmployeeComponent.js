import React, {useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import EmployeeService from '../services/EmployeeService'
import Swal from 'sweetalert2';
import Pagination from "@material-ui/lab/Pagination";

const ListEmployeeComponent = () => {

    const [page, setPage] = useState(1);

    const [count, setCount] = useState(0);

    const [size, setSize] = useState(3);

    const pageSizes = [3,4,5];

    const [employees, setEmployees] = useState([])

    

    useEffect(() => retrieveEmployees(),[page, size]);



    const getRequestParams = (page, size) => {

        let params = {};

        if (page) {

          params["page"] = page - 1;

        }

        if (size) {

          params["size"] = size;

        }

        return params;

      };

   

    const retrieveEmployees = () => {

    const params = getRequestParams(page, size);

    EmployeeService.getAllEmployeeByPages(params.page,params.size)

        .then((response) => {

        const { employees, totalPages } = response.data;

        setEmployees(employees);

        setCount(totalPages);

        console.log(response.data);

        })

        .catch((e) => {

        console.log(e);

        });

    };



    const handlePageChange = (event, value) => {

        setPage(value);

    };

    const handlePageSizeChange = (event) => {

        setSize(event.target.value);

        setPage(1);



    };
    
    

    const getAllEmployees = () => {
        EmployeeService.getAllEmployees().then((response) => {
            setEmployees(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    }
   

    
    const deleteEmployee = (Id) => {

        Swal.fire({

            icon: 'warning',

            title: 'Are you sure?',

            text: "You won't be able to revert this!",

            showCancelButton: true,

            confirmButtonText: 'Yes, delete it!',

            cancelButtonText: 'No, cancel!',

        }).then((response) => {

            if(response.value){

                EmployeeService.deleteEmployee(Id);

                Swal.fire({

                    icon: 'success',

                    title: 'Deleted!',

                    text: `${employees.name}'s data has been deleted.`,

                    showConfirmButton: false,

                    timer: 3000,

                });
                

                getAllEmployees();

               

            }  

        }).catch((error) => {

            console.log(error)

        })

    }

    return (
        <div className = "container">
            <h3 className = "text-center mt-3"> List Employees </h3>
            <Link to = "/add-employee" className = "btn btn-primary mb-2" > Add Employee </Link> &nbsp;&nbsp;&nbsp;&nbsp;
            <Link to ='/department' className='btn btn-primary mb-2'> View Departments </Link>&nbsp;&nbsp; &nbsp;&nbsp;
            <Link to ='/desc-employee' className='btn btn-primary mb-2'> Desc Employee</Link>&nbsp;&nbsp; &nbsp;&nbsp;
            <Link to ='/asc-employee' className='btn btn-primary mb-2'> Asc Employee</Link>&nbsp;&nbsp; &nbsp;&nbsp;
 

            <table className="table table-bordered table-striped">
                <thead>
                    <th>Employee Name</th>
                    <th>Employee Sal</th>
                    <th> Employee Age</th>
                    <th> Employee email</th>
                    <th>Employee Joining-Date</th>
                     <th>Employee dName</th>
                    <th>Employee deptId</th> 
                    <th> Actions </th>
                </thead>
                <tbody>
                    {
                        employees.map(
                            employee =>
                            <tr key = {employee.eId}> 
                                <td> {employee.eName} </td>
                                <td>{employee.eSal}</td>
                                <td>{employee.eAge}</td>
                                <td>{employee.email}</td>
                                <td>{employee.date}</td>
                                 <td>{employee.dept.dName}</td> 
                                 <td>{employee.dept.deptId}</td> 
                                <td>
                                    <Link className="btn btn-info" to={`/edit-employee/${employee.eId}`} >Update</Link>
                                    <button className = "btn btn-danger" onClick = {() => deleteEmployee(employee.eId)}
                                    style = {{marginLeft:"10px"}}> Delete</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
            <div className="mt-3">

          {"Items per Page: "}

          <select onChange={handlePageSizeChange} value={size}>

            {pageSizes.map((size) => (

              <option key={size} value={size}>

                {size}

              </option>

            ))}

          </select>

          <Pagination

            className="my-3"

            count={count}

            page={page}

            siblingCount={1}

            boundaryCount={1}

            variant="outlined"

            shape="rounded"

            onChange={handlePageChange}

          />

        </div>
        </div>
    )
}

export default ListEmployeeComponent
