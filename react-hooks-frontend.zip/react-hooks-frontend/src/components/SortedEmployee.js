import React, {useState, useEffect} from 'react'
import { Link, useParams } from 'react-router-dom'
import EmployeeService from '../services/EmployeeService'
import Swal from 'sweetalert2';
import ReactPaginate from 'react-paginate';

const SortedEmployeeComponent = () => {
    const [page, setPage] = useState(1);

    const [count, setCount] = useState(0);

    const [size, setSize] = useState(3);

    const pageSizes = [3,4,5];

    const [employees, setEmployees] = useState([])

    useEffect(() => {

        desc();
        asc();
        
        
    }, [])

    const desc = () => {
        
        EmployeeService.desc().then((response) => {
            setEmployees(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    
    }
    const asc = () => {
        EmployeeService.asc().then((response) => {
            setEmployees(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    
    }
   

    
    

    return (
        <div className = "container">
            <h3 className = "text-center mt-3"> Desc Employees </h3>
            <Link to = "/add-employee" className = "btn btn-primary mb-2" > Add Employee </Link> &nbsp;&nbsp;
            <Link to ='/department' className='btn btn-primary mb-2'> View Departments </Link> &nbsp;&nbsp; 
            <Link to = "/employees" className = "btn btn-primary mb-2" color='black'> back </Link> 
 

            <table className="table table-bordered table-striped">
                <thead>
                    <th>Employee Name</th>
                    <th>Employee Sal</th>
                    <th> Employee Age</th>
                    <th> Employee email</th>
                    <th>Employee Joining-Date</th>
                     <th>Employee dName</th>
                    <th>Employee deptId</th> 
                    <th> Actions </th>
                </thead>
                <tbody>
                    {
                        employees.map(
                            employee =>
                            <tr key = {employee.eId}> 
                                <td> {employee.eName} </td>
                                <td>{employee.eSal}</td>
                                <td>{employee.eAge}</td>
                                <td>{employee.email}</td>
                                <td>{employee.date}</td>
                                 <td>{employee.dept.dName}</td> 
                                 <td>{employee.dept.deptId}</td> 
                                <td>
                                    <Link className="btn btn-info" to={`/edit-employee/${employee.eId}`} >Update</Link>

                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
            <ReactPaginate

         previousLabel={'previous'}

         nextLabel={'next'}

         breakLabel={'...'}

         pageCount={25}

         marginPagesDisplayed={3}

         pageRangeDisplayed={3}

         onPageChange={ 'handlePageClick'}

         containerClassName={'pagination justify-content-center'}

         pageClassName={'page-item'}

         pageLinkClassName={'page-link'}

         previousClassName={'page-item'}

         previousLinkClassName={'page-link'}

         nextClassName = {'page-item'}

         nextLinkClassName={'page-link'}

         breakClassName={'page-item'}

         breakLinkClassName={'page-link'}

         activeClassName={'active'}

         >

         </ReactPaginate>
        </div>
    )
}

export default SortedEmployeeComponent
