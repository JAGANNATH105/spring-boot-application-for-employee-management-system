import React, {useState, useEffect} from 'react'
import {Link, useHistory, useParams } from 'react-router-dom';
import DepartmentService from '../services/DepartmentService'



const AddDepartmentComponents = () => {

    const [dName, setdName] = useState('')
    const [deptId, setdeptId] = useState()
    const history = useHistory();
    const {id} = useParams();

    

    const saveOrUpdatedept = (e) => {
        e.preventDefault();
        

        const dept = {dName, deptId}

        if(id){
            DepartmentService.updatedept(id, dept).then((response) => {
                history.push('/department')
            }).catch(error => {
                console.log(error)
            })

        }else{
            DepartmentService.createdept(dept).then((response) =>{

                console.log(response.data)
    
                history.push('/department');
                
                
    
            }).catch(error => {
                console.log(error)
            })
        }
        
    }

    useEffect(() => {

        DepartmentService.getdeptById(id).then((response) =>{
            setdName(response.data.dName)
            setdeptId(response.data.deptId)
            // setEmailId(response.data.emailId)
        }).catch(error => {
            console.log(error)
        })
    }, [])

    const title = () => {

        if(id){
            return <h2 className = "text-center">Update dept</h2>
        }else{
            return <h2 className = "text-center">Add dept</h2>
        }
    }

    return (
        <div>
           <br /><br />
           <div className = "container">
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                       {
                           title()
                       }
                        <div className = "card-body">
                            <form>
                                
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Dept id :</label>
                                    <input
                                        type = "number"
                                        placeholder = "Enter last name"
                                        name = "deptId"
                                        className = "form-control"
                                        value = {deptId}
                                        onChange = {(e) => setdeptId(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Dept Name :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter first name"
                                        name = "dName"
                                        className = "form-control"
                                        value = {dName}
                                        onChange = {(e) => setdName(e.target.value)}
                                    >
                                    </input>
                                </div>


                                

                                <button className = "btn btn-success" onClick = {(e) => saveOrUpdatedept(e)} >Submit </button>
                                <Link to="/department" className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default AddDepartmentComponents


