import React, {useState, useEffect} from 'react'
import {Link, useHistory, useParams } from 'react-router-dom';
import EmployeeService from '../services/EmployeeService'
import Swal from 'sweetalert2';



const AddEmployeeComponent = () => {

    const [eName, seteName] = useState('')
    const [eSal, seteSal] = useState()
    const [eId, seteId] = useState()
    const [eAge, seteAge]=useState()
     const [deptId,setdeptId]=useState()
    const [dName,setdName]=useState('')
    const [email,setemail]=useState('')
    const[date,setdate]=useState()
    const history = useHistory();
    const {id} = useParams();


    const dept={
        deptId,
        dName
    }

    const saveOrUpdateEmployee = (e) => {
        e.preventDefault();

        const employee = {eName, eSal ,eAge,email,date,dept}

        if(id){

            Swal.fire({

                icon: 'warning',
    
                title: 'Are you sure to update data?',
    
                text: "You won't be able to revert this!",
    
                showCancelButton: true,
    
                confirmButtonText: 'Yes, update it!',
    
                cancelButtonText: 'No, cancel!',
    

        })
            .then((response) => {
                if(response.value){
                    EmployeeService.updateEmployee(id, employee);
                    Swal.fire({
                        icon: 'success',

                        title: 'Added!',
    
                        text: `${employee.eName}'s data has been Added.`,
    
                        showConfirmButton: false,
    
                        timer: 1500
                    }

                    )}
                history.push('/employees')
            }).catch(error => {
                console.log(error)
            })

        }else{
            Swal.fire({

                icon: 'warning',
    
                title: 'Are you sure to Add employee?',
    
                text: "You won't be able to revert this!",
    
                showCancelButton: true,
    
                confirmButtonText: 'Yes, add it!',
    
                cancelButtonText: 'No, cancel!',
    

        }).then((response) => {
                    if(response.value){
                        EmployeeService.createEmployee(employee);
                        Swal.fire({
                            icon: 'success',
    
                            title: 'Added!',
        
                            text: `${employee.eName}'s data has been Added.`,
        
                            showConfirmButton: false,
        
                            timer: 1500
                        }
    
                        );
                    }                

                    history.push('/employees')

                }).catch(error => {
                console.log(error)
            })
        }
        
    }

    useEffect(() => {

        EmployeeService.getEmployeeById(id).then((response) =>{
            seteName(response.data.eName)
            seteSal(response.data.eSal)
            seteId(response.data.eId)
            seteAge(response.data.eAge)
            setemail(response.data.email)
            setdate(response.data.date)
            setdeptId(response.data.dept.deptId)
            // setdName(response.data.dName)
        }).catch(error => {
            console.log(error)
        })
    }, [])

    

    const title = () => {

        if(id){
            return <h2 className = "text-center">Update Employee</h2>
        }else{
            return <h2 className = "text-center">Add Employee</h2>
        }
    }

    return (
        <div>
           <br /><br />
           <div className = "container">
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                       {
                           title()
                       }
                        <div className = "card-body">
                            <form>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> First Name :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Employee Name"
                                        name = "eName"
                                        className = "form-control"
                                        value = {eName}
                                        onChange = {(e) => seteName(e.target.value)}
                                    >
                                    </input>
                                </div>

                            
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Email  :</label>
                                    <input
                                        type = "email"
                                        placeholder = "Enter Employee  Email"
                                        name = "email"
                                        className = "form-control"
                                        value = {email}
                                        onChange = {(e) => setemail(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Salary :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Employee Salary"
                                        name = "eSal"
                                        className = "form-control"
                                        value = {eSal}
                                        onChange = {(e) => seteSal(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label">  Joining Date :</label>
                                    <input
                                        type = "date"
                                        placeholder = "Enter Joining Date"
                                        name = "date"
                                        className = "form-control"
                                        value = {date}
                                        onChange = {(e) => setdate(e.target.value)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label">  Age :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Employee Age"
                                        name = "eAge"
                                        className = "form-control"
                                        value = {eAge}
                                        onChange = {(e) => seteAge(e.target.value)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label">  Department-Id :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Employee Department-Id"
                                        name = "deptId"
                                        className = "form-control"
                                        value = {deptId}
                                        onChange = {(e) => setdeptId(e.target.value)}
                                    >
                                    </input>
                                </div>
                                

                                <button   className = "btn btn-success" onClick = {(e) => saveOrUpdateEmployee(e) }  >Submit  </button>
                                <Link to="/employees" className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default AddEmployeeComponent
