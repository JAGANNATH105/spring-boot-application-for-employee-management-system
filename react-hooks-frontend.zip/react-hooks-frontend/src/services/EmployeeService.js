import axios from 'axios'

const EMPLOYEE_BASE_REST_API_URL = 'http://localhost:8080/api/v1/employees';

class EmployeeService{

    getAllEmployees(){
        return axios.get(EMPLOYEE_BASE_REST_API_URL)
    }
    getAllEmployeeByPages(page,pageSize){

        return axios.get(EMPLOYEE_BASE_REST_API_URL + '/paging/' + page + '/' + pageSize)

    }

    createEmployee(employee){
        return axios.post(EMPLOYEE_BASE_REST_API_URL, employee)
    }

    getEmployeeById(employeeId){
        return axios.get(EMPLOYEE_BASE_REST_API_URL + '/' + employeeId);
    }

    updateEmployee(employeeId, employee){
        return axios.put(EMPLOYEE_BASE_REST_API_URL + '/' +employeeId, employee);
    }

    deleteEmployee(employeeId){
        return axios.delete(EMPLOYEE_BASE_REST_API_URL + '/' + employeeId);
    }
     desc(){
        return axios.get(EMPLOYEE_BASE_REST_API_URL + '/desc' );
     }
     asc(){
        return axios.get(EMPLOYEE_BASE_REST_API_URL + '/asc' );
     }

    getAllDept(){
        return axios.get(EMPLOYEE_BASE_REST_API_URL + '/' )

    }
}

export default new EmployeeService();