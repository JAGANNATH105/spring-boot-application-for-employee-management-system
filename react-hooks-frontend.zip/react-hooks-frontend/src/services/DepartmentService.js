import axios from 'axios'

const dept_BASE_REST_API_URL = 'http://localhost:8080/api/v1/dept';

class DepartmentService{

    getAlldepts(){
        return axios.get(dept_BASE_REST_API_URL)
    }
    getAllEmployeeByPages(page,pageSize){

        return axios.get(dept_BASE_REST_API_URL + '/paging/' + page + '/' + pageSize)

    }

    deletedept(deptId){
        return axios.delete(dept_BASE_REST_API_URL + '/' + deptId);
    }


    createdept(dept){
        return axios.post(dept_BASE_REST_API_URL, dept)
    }

    updatedept(deptId, dept){
        return axios.put(dept_BASE_REST_API_URL + '/' +deptId, dept);
    }

    getdeptById(deptId){
        return axios.get(dept_BASE_REST_API_URL + '/' + deptId);
    }

    

   
    // desc(deptId){
    //     return axios.get(dept_BASE_REST_API_URL + '/desc' + deptId);
    // }
    // getAllDept(){
    //     return axios.get(dept_BASE_REST_API_URL + '/' )

    // }
}

export default new DepartmentService();